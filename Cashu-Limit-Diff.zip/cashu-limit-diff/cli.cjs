#!/usr/bin/env node
// SPDX-License-Identifier: MIT
"use strict";
const fs = require("node:fs");
const {compare} = require("./limits.js");
const args = process.argv.slice(2);
const fail = args[0] === "--fail-on-loss";
if (fail) args.shift();
if (args.length !== 2) {
  console.error("Usage: node cli.cjs [--fail-on-loss] before.json after.json");
  process.exitCode = 2;
} else {
  try {
    const result = compare(...args.map(file => JSON.parse(fs.readFileSync(file, "utf8"))));
    console.log(JSON.stringify(result, null, 2));
    if (fail) {
      if (result.unknown.length) process.exitCode = 3;
      else if (result.changes.some(row => row.lost.length)) process.exitCode = 1;
    }
  } catch (error) {
    console.error(error.message);
    process.exitCode = 2;
  }
}
