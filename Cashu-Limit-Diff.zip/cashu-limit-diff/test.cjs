// SPDX-License-Identifier: MIT
const test = require("node:test"), assert = require("node:assert/strict");
const {compare} = require("./limits.js");
const row = (min_amount, max_amount, method="bolt11", unit="sat") => ({method,unit,min_amount,max_amount});
const info = (methods, disabled=false) => ({nuts:{4:{methods,disabled},5:{methods:[],disabled:false}}});
test("inclusive narrowing, widening and an amount disabled for melting", () => {
  const report=compare(require("./examples/before.json"),require("./examples/after.json"));
  assert.deepEqual(report.changes.map(x=>[x.lost,x.gained]),[[[["10","99"]],[["10001","15000"]]],[[["1","1000"]],[]]]);
});
test("zero-only operations do not accept positive amounts; missing endpoints are unbounded",()=>{
  const report=compare(info([row(null,null)]), info([row(0,0)]));
  assert.deepEqual(report.changes[0].lost,[["1",null]]);
});
test("duplicate, overlapping and disjoint intervals keep exact gaps",()=>{
  const a=info([row(1,3),row(3,4),row(6,7)]), b=info([row(2,6)]);
  const r=compare(a,b).changes[0]; assert.deepEqual(r.lost,[["1","1"],["7","7"]]); assert.deepEqual(r.gained,[["5","5"]]);
});
test("missing snapshot section is marked unknown instead of a removal",()=>{
  const r=compare({}, info([row(1,5)]));assert.equal(r.unknown.length,2);assert.deepEqual(r.changes,[]);
});
test("method and unit identify independent schedules",()=>{
  const a=info([row(1,9),row(1,6,"bolt12","eur")]), b=info([row(1,9),row(2,9,"bolt12","eur")]);
  assert.deepEqual(compare(a,b).changes,[{operation:"mint",method:"bolt12",unit:"eur",lost:[["1","1"]],gained:[["7","9"]]}]);
});
test("malformed settings produce a diagnostic",()=>{
  for(const x of [info([row(9,2)]),info([row("5",9)]),info([row(1,Number.MAX_SAFE_INTEGER+1)]),info([], "false"),{nuts:null}]) assert.throws(()=>compare(x, info([])));
});
test("large range edge remains exact without walking individual amounts",()=>{
  const r=compare(info([row(1,null)]),info([row(1,Number.MAX_SAFE_INTEGER)]));
  assert.deepEqual(r.changes[0].lost,[["9007199254740992",null]]);
});
test("enumerated small schedules agree exactly with range result",()=>{
  for(let a=0;a<64;a++)for(let b=0;b<64;b++){
    const rows=bits=>Array.from({length:6},(_,i)=>i+1).filter(n=>bits & (1<<(n-1))).map(n=>row(n,n));
    const r=compare(info(rows(a)),info(rows(b))).changes[0]||{gained:[],lost:[]};
    const contains=(ranges,n)=>ranges.some(([l,h])=>Number(l)<=n && (h===null || n<=Number(h)));
    for(let i=1;i<=6;i++){
      const bit=1<<(i-1);
      assert.equal(contains(r.lost,i),Boolean((a&~b)&bit));
      assert.equal(contains(r.gained,i),Boolean((b&~a)&bit));
    }
  }
});
