/* SPDX-License-Identifier: MIT */
/* The same dependency-free engine powers the offline page and the Node CLI. */
(function (root) {
  "use strict";
  const operations = [["4", "mint"], ["5", "melt"]];
  const record = value => value !== null && typeof value === "object" && !Array.isArray(value);

  function endpoint(value, fallback, where) {
    if (value === null || value === undefined) return fallback;
    if (!Number.isSafeInteger(value) || value < 0)
      throw new Error(where + " must be a nonnegative safe JSON integer or null");
    return BigInt(value);
  }

  function combine(parts) {
    const result = [];
    const sorted = [...parts].sort((a, b) => a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0);
    for (const [lo, hi] of sorted) {
      const last = result[result.length - 1];
      if (!last || (last[1] !== null && lo > last[1] + 1n)) {
        result.push([lo, hi]);
      } else if (last[1] !== null && (hi === null || hi > last[1])) {
        last[1] = hi;
      }
    }
    return result;
  }

  function subtract(source, other) {
    const result = [];
    for (const [start, end] of source) {
      let cursor = start;
      for (const [lo, hi] of other) {
        if (hi !== null && hi < cursor) continue;
        if (end !== null && lo > end) break;
        if (lo > cursor) result.push([cursor, lo - 1n]);
        if (hi === null || (end !== null && hi >= end)) { cursor = null; break; }
        cursor = hi + 1n;
      }
      if (cursor !== null) result.push([cursor, end]);
    }
    return result;
  }

  function parseOperation(nuts, id, side) {
    if (!(id in nuts)) return null;
    const conf = nuts[id], label = side + " NUT-0" + id;
    if (!record(conf) || typeof conf.disabled !== "boolean" || !Array.isArray(conf.methods))
      throw new Error(label + " requires a boolean disabled and a methods array");
    const pairs = new Map();
    for (const [i, row] of conf.methods.entries()) {
      const where = label + " methods[" + i + "]";
      if (!record(row) || [row.method, row.unit].some(x => typeof x !== "string" || !x.trim()))
        throw new Error(where + " needs nonempty method and unit strings");
      const min = endpoint(row.min_amount, 0n, where + ".min_amount");
      const max = endpoint(row.max_amount, null, where + ".max_amount");
      if (max !== null && min > max) throw new Error(where + " has reversed bounds");
      const key = JSON.stringify([row.method, row.unit]);
      if (!pairs.has(key)) pairs.set(key, []);
      if (!conf.disabled && (max === null || max > 0n))
        pairs.get(key).push([min > 0n ? min : 1n, max]);
    }
    for (const [key, ranges] of pairs) pairs.set(key, combine(ranges));
    return pairs;
  }

  function nutsOf(snapshot, label) {
    if (!record(snapshot)) throw new Error(label + " must be a /v1/info JSON object");
    if (!Object.hasOwn(snapshot, "nuts")) return {};
    if (!record(snapshot.nuts)) throw new Error(label + ".nuts must be an object");
    return snapshot.nuts;
  }

  function printable(ranges) {
    return ranges.map(([lo, hi]) => [lo.toString(), hi === null ? null : hi.toString()]);
  }

  function compare(before, after) {
    const a = nutsOf(before, "Before"), b = nutsOf(after, "After");
    const changes = [], unknown = [];
    let comparable = 0;
    for (const [id, operation] of operations) {
      const old = parseOperation(a, id, "Before"), next = parseOperation(b, id, "After");
      if (old === null || next === null) {
        unknown.push({operation, missingBefore: old === null, missingAfter: next === null});
        continue;
      }
      comparable++;
      const keys = [...new Set([...old.keys(), ...next.keys()])].sort();
      for (const key of keys) {
        const left = old.get(key) || [], right = next.get(key) || [];
        const lost = subtract(left, right), gained = subtract(right, left);
        if (lost.length || gained.length) {
          const [method, unit] = JSON.parse(key);
          changes.push({operation, method, unit, lost: printable(lost), gained: printable(gained)});
        }
      }
    }
    return {comparable, unknown, changes};
  }

  const api = {compare};
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.CashuLimits = api;
})(globalThis);
