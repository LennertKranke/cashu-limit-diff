// SPDX-License-Identifier: MIT
"use strict";
const byId = id => document.getElementById(id);
const fmt = ranges => ranges.map(([lo, hi]) => hi === null ? lo + "+" : lo === hi ? lo : lo + "–" + hi).join(", ") || "—";

function render() {
  const table = byId("results"), body = table.tBodies[0];
  body.replaceChildren();
  table.hidden = true;
  byId("warnings").textContent = "";
  try {
    const result = CashuLimits.compare(JSON.parse(byId("before").value), JSON.parse(byId("after").value));
    for (const r of result.changes) {
      const row = body.insertRow();
      for (const value of [r.operation, r.method + " / " + r.unit, fmt(r.lost), fmt(r.gained)])
        row.insertCell().textContent = value;
    }
    table.hidden = !result.changes.length;
    byId("summary").textContent = result.changes.length ?
      result.changes.length + " changed method/unit pair(s)." :
      result.comparable ? "No changes in the comparable operations." : "No comparable operations.";
    byId("warnings").textContent = result.unknown.map(x => {
      const side = [x.missingBefore && "before", x.missingAfter && "after"].filter(Boolean).join(" and ");
      return "Unknown " + x.operation + " limits: settings missing " + side + ".";
    }).join(" ");
  } catch (e) {
    byId("summary").textContent = "Cannot compare: " + e.message;
  }
}
byId("example").onclick = () => {
  function info(lo, hi, disabled) {
    return {nuts: {
      4: {disabled: false, methods: [{method:"bolt11",unit:"sat",min_amount:lo,max_amount:hi}]},
      5: {disabled, methods: [{method:"bolt11",unit:"sat",min_amount:1,max_amount:1000}]}
    }};
  }
  byId("before").value = JSON.stringify(info(10, 10000, false), null, 2);
  byId("after").value = JSON.stringify(info(100, 15000, true), null, 2);
  render();
};
byId("form").onsubmit = event => { event.preventDefault(); render(); };
